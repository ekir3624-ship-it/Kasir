<?php
include "boot.php";
?>
<link rel="stylesheet" href="style.css">
<div class="container mt-5 " style="width: 400px">
<div class="shadow-lg p-3 mb-5 bg-body-tertiary rounded">
<div class="p-3 mb-3 bg-light "style="max-width: 25rem ;">
</div>
<h1><b>LOGIN</h1></b>
<div class="container mt-5"></div>
<form action="" method="post">
<body style="background-size:cover" background="warning">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">username</label>
    <input type="text" class="form-control" id="username" name="username" placeholder="Masukan username">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="Password" name="password" placeholder="Masukan password">
  </div>
  <input type="submit" name="login" class="btn btn-primary" value="login">
</form>
</div>
</div>
</body>

<?php

include "koneksi.php";
session_start();

if(isset($_POST['login'])) {

    $username=$_POST['username'];
    $password=$_POST['password'];

$kueri      = "select * from aman where username='$username' and password='$password'";
$aman       = $konek -> query ($kueri);
$cek        = $aman  -> num_rows;
$tampil     = $konek -> query ("select * from aman where username ='$username'");
$level      = $tampil -> fetch_array();

if ($cek > 0) {

    if ($level['level']== 'admin'){


    $_SESSION[ 'username'] = $username;
?>
    <script>
    document.location='tampil.php';
    </script>

<?php
}
}else{
    echo"<div class='alert alert-danger alert-dismissible fade show col-6 'style='margin-left:350px;' role='alert'>
    <strong><i class='bi bi-exclamation-triangle-fill'></i></strong> GAGAL LOGIN Usernmae Dan Password tidak sesuai.
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
  </div>";
}


}


?>