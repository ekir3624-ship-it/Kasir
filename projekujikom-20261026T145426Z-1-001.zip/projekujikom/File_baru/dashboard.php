<?php
include "boot.php";
include "koneksi.php";
include "rupiah.php";
$date = date('Y-m-d');
$total_bayar = mysqli_query($konek, "SELECT SUM(total) AS totbar FROM transaksi WHERE tanggal = '$date' ");
$totall = mysqli_fetch_assoc($total_bayar);
$jumlaproduk = mysqli_query($konek, "SELECT COUNT(*) AS makanan FROM produk ");
$makanan = mysqli_fetch_assoc($jumlaproduk);


?>
<div class="alert bg-warning mt-2 text-center" role="alert">
    <h3><b><i class="bi "></i> DASHBOARD</b></h3>
</div>


<div id="layoutSidenav_content">
    <div class="row">
        <div class="col-md-3">
            <div class="card border-primary mb-3">
                <div class="row">
                    <div class="col-md-2">
                        <i class="fa fa-sharp p-3 mt-2 fa-4x"></i>
                    </div>
                    <div class="col-md-10">
                        <div class="ml-5 card-body">
                            <h6 class="card-title">Total Produk : </h6>
                            <span class="btn btn-warning text-white btn-sm text-small"><?= $makanan['makanan'] ?>
                                Produk</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-primary mb-3">
                <div class="row">
                    <div class="col-md-2">
                        <i class="fa fa-book-user p-3 mt-2 fa-4x"></i>
                    </div>
                    <div class="col-md-10">
                        <div class="ml-4 card-body">
                            <h6 class="card-title">Total Pelanggan :</h6>
                            <span class="btn btn-success text-white btn-sm text-small"> Pelanggan</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-primary mb-3">
                <div class="row">
                    <div class="col-md-2">
                        <i class="fa fa-book-user p-3 mt-2 fa-4x"></i>
                    </div>
                    <div class="col-md-10">
                        <div class="ml-4 card-body">
                            <h6 class="card-title"> Pendapatan hari ini : <?= $date; ?></h6>
                            <span class="btn btn-success btn-sm text-small"> Rp.<?= rupiah($totall['totbar']) ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-primary mb-3">
                <div class="row">
                    <div class="col-md-2">
                        <i class="fa fa-book p-3 mt-2 fa-4x"></i>
                    </div>
                    <div class="col-md-10">
                        <div class="ml-4 card-body">
                            <h6 class="card-title">Pendapatan Perbulan</h6>

                            <a href="index.php?laporan">
                                <span class="btn btn-danger btn-sm text-small"><i class="fa fa-eye"></i> Lihat
                                    laporan</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>